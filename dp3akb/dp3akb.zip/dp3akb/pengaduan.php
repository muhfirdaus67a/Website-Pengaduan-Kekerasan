<?php
$koneksi = new mysqli("localhost", "root", "", "pkl");

if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error);
}
  $query = "SELECT * FROM berita ORDER BY id_berita DESC LIMIT 3";
  $result = mysqli_query($koneksi, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Baloo+2&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">
  
  <title>Layanan Pengaduan Kekerasan DP3AKB Jember</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins';
      
    }

    body {
      min-height: 100vh;
     background-color: rgb(12, 51, 180);
    }

    body h1, h2, h3, h4 {
      font-family: 'Baloo 2', cursive;
      font-weight: bold;
    }

    body p {
      font-family: 'Poppins';
      font-size: 16px;
    }

    section {
       
      display: none;
      padding-top: 90px;
    }

    section.active {
      display: block;
    }

    .navbar {
    width: 100%;
    background-color: rgb(12, 51, 180);
    color: white;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    padding: 15px 30px;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 10;
    margin: 0 auto;
    }

    .navbar .logo {
      font-size: 20px;
      margin-right: 30px;
    }

    .navbar ul {
      display: flex;
      list-style: none;
      gap: 40px;
      margin-left: 140px;
      padding-right: 10px;
    }

    .navbar ul li a {
      font-family: 'Baloo 2';
      font-size: 19px;
      font-weight: bold;
      color: white;
      text-decoration: none;
      
    }

    .navbar ul li a:hover {
      text-decoration: underline;
    }

.dashboard-container {
  display: flex;
  flex-direction: row;
  min-height: calc(100vh - 70px);
  padding-left: 20px;
  color: white;
}

.dashboard-kiri {
  flex: 3;
  display: flex;
  flex-direction: column;
  margin-left: 30px;
}

.dashboard-content {
  display: flex;
  flex-direction: row;
  border-bottom: 2px solid rgb(255, 255, 255);
  
  padding-bottom: 10px;

}

.dashboard-image {
  flex: 1;
}

.dashboard-text {
  flex: 2;
  margin-top: 13px;
}

.dashboard-image img {
  width: 80%;
  max-width: 250px;
  height: auto;
  border-radius: 6px;
  border: 2px solid white;
  text-align: center;
}

.dashboard-panduan {
  margin-top: 10px;
}

.panduan-container {
  display: flex;
  flex-direction: row;
  gap: 20px;
}

.panduan-container h4 {
  text-decoration:underline; 
  margin-left: 34px;
  margin-top: 8px;
  margin-bottom: 26px;
}

.panduan-pengisian, .panduan-cek {
  flex: 1;
  padding: 10px;
}

.circle-list {
  list-style: none;
  counter-reset: step;
  padding-left: 0;
}

.circle-list li {
  counter-increment: step;
  margin-bottom: 22px;
  position: relative;
  padding-left: 40px;
}

.circle-list li::before {
  content: counter(step);
  position: absolute;
  left: 0;
  top: 0;
  width: 30px;
  height: 30px;
  background:rgb(255, 255, 255);
  color: #2563eb;
  border-radius: 50%;
  text-align: center;
  line-height: 30px;
  font-weight: bold;
}

.dashboard-berita {
  display: flex;
  flex: 1;
  flex-direction: column;
  align-items: center;
  border-radius: 20px;
  gap: 16px;
}

.box-berita {
  display: flex;
  flex-direction: column;
  background-color: white;
  border: 2px solid white;
  border-radius: 8px;
  overflow: hidden;
  width: 200px;
  height: 180px; /* tinggi total box */
}

.berita-image {
  flex: 4;
  overflow: hidden;
}

.berita-image img {
  width: 100%;
  height: 100%;
  background-size: cover;
  
}

.berita-judul {
  font-size: 14px;
  flex: 1; /* judul mengambil 1/4 ruang */
  color: black;
  padding: 2px;
  text-align: left;
  word-wrap: break-word;
  overflow-wrap: break-word;
  overflow: hidden;
  white-space: normal;
}
.berita-judul h4 {
  text-align: center;
font-family: "Lilita One", sans-serif;
  font-weight: 400;
  font-style: normal;
  text-transform: uppercase;
}
    

    .form-container {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(179, 12, 12, 0.1);
      max-width: 800px;
      margin: 20px auto;
      width: 100%;
      margin-top: 10px;
      max-height: 500px;
    }

    .form-group {
      display: flex;
      align-items: center;
      margin-bottom: 15px;
    }

    .label {
      width: 100px;
      text-align: right;
     
    }

    .colon {
      width: 10px;
      text-align: center;
      margin-right: 10px;
      
    }

    .form-group label {
      width: 150px;
      display: block;
      font-weight: 400;
      font-size: 16px;
      margin-right: 10px;
    }

    .form-group input,
    .form-group textarea {
      flex: 1;
      width: 100%;
      padding: 8px;
      border-radius: 9px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    .form-group textarea {
      resize: vertical;
      height: 50px;
    }

    .form-group input[type="file"] {
      border: none;
      padding: 5px;
    }

    .input, textarea {
      flex: 1;
      padding: 8px;   
    }

    select {
      flex: 1;
      width: 100%;
      padding: 8px;
      border-radius: 9px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    .submit-btn {
      display: block;
      background-color: #2563eb;
      color: white;
      padding: 8px 14px;
      border: none;
      border-radius: 9px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s;
      margin: 20px auto;
    }

    .submit-btn:hover {
      background-color: #1d4ed8;
    }

.about-container {
  display: grid;
  grid-template-columns: 1fr 1fr; /* dua kolom */
  grid-template-rows: 1fr 1fr;    /* dua baris */
  gap: 10px;
  height: 100vh;
  padding: 30px;
  box-sizing: border-box;
}

.about-box {
  border: none;
  overflow: hidden;
  position: relative;
  box-sizing: border-box;
}

.about-box iframe {
  width: 400px;
  height: 200px;
  border-radius: 12px;
  border: 3px solid white;
  
}

.container-contact {
  display: flex;
  flex-direction: column;
}

.logo-contact {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 16px;
  color: white;
}

.logo-contact i {
  width: 40px;
  height: 40px;
  background-color: white;
  color: #2563eb;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  margin-right: 10px;
  flex-shrink: 0;
}

.about-contact {
  padding-top: 14px;
  display: flex;
  flex-direction: column;
  gap: 25px;
}

.about-medsos {
  display: flex;
  align-items: center;
  gap: 10px;
  padding-top: 100px;
}

.about-medsos i {
  width: 100px;
  height: 100px;
  font-size: 60px;
  background-color: white;
  color: #2563eb;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 10px;
  flex-shrink: 0;
  text-decoration: none;
}

.about-medsos a {
  text-decoration: none;
}

/* Ulasan Section */
.ulasan-container {
  background-color: #1d4ed8;
  padding: 60px 20px;
  text-align: center;
  color: white;
  max-width: 800px;
  margin: 0 auto;
  border-radius: 10px;
  border: 4px solid #ccc;
}

.title-ulasan {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 15px;
}

/* Bintang */
.star-rating {
  font-size: 40px;
  margin-bottom: 30px;
  display: flex;
  justify-content: center;
  gap: 15px;
  cursor: pointer;
}

.star {
  color: white;
  transition: color 0.3s;
}

.star.active {
  color: gold;
}

/* Form ulasan */
.ulasan-form {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 15px;
}

.ulasan-label {
  font-size: 16px;
  font-weight: 600;
}

.textarea_1 {
  width: 100%;
  max-width: 500px;
  padding: 20px;
  border-radius: 25px;
  border: none;
  resize: none;
  font-size: 16px;
}

.button_1[type="submit"] {
  background-color: white;
  color: #1d4ed8;
  border: none;
  padding: 10px 25px;
  border-radius: 20px;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s;
}

.button_1[type="submit"]:hover {
  background-color: #e0e0e0;
}


  </style>
</head>
<body>

  <!--Navbar-->
  <div class="navbar">
    <div class="logo">
      <img src="image/logoputih.png" alt="Logo" style="height:40px;">
    </div>
    <ul>
      <li><a href="#" onclick="showSection('dashboard')">Dashboard</a></li>
      <li><a href="#" onclick="showSection('pengaduan')">Pengaduan</a></li>
      <li><a href="#" onclick="showSection('cek')">Cek Pengaduan</a></li>
      <li><a href="#" onclick="showSection('ulasan')">Ulasan</a></li>
      <li><a href="#" onclick="showSection('about')">About</a></li>
      <li><a href="login.php" onclick="showSection('login')">Admin</a></li>
    </ul>
  </div>

    <section id="dashboard" class="">
      <div class="dashboard-container">
        <div class="dashboard-kiri">
          <div class="dashboard-content">
            <div class="dashboard-image">
              <img src="image/kantor.jpg" alt="kantor DP3aKB">
            </div>

            <div class="dashboard-text">
              <h1 style="margin-bottom: 11px;  font-family: 'Baloo 2', cursive;">DPPPAKB Kabupaten Jember</h1>
              <p>
              DP3AKB merupakan unsur pelaksana urusan pemerintahan di Kabupaten Jember di bidang pemberdayaan perempuan dan perlindungan anak serta urusan pemerintahan di bidang pengendalian penduduk dan keluarga berencana. 
              </p>
            </div>
            
          </div>
      
          <div class="dashboard-panduan">
            <h2 style="text-align: center;">Panduan Pengaduan</h2>

            <div class="panduan-container">
              <div class="panduan-pengisian">
                <h4 style="font-size: 19px;">Pengisian Pengaduan</h4>
                <ol class="circle-list">
                  <li>Pilih Halaman Pengaduan</li>
                  <li>Isi form pengaduan sesuai laporan yang diajukan</li>
                  <li>Klik kirim laporan</li>
                </ol>
              </div>
                
              <div class="panduan-cek">
              <h4 style="font-size: 19px;">Pengecekan Pengaduan</h4>
                <ol class="circle-list">
                  <li>Pilih halaman cek pengaduan</li>
                  <li>Masukkan nomor tiket</li>
                  <li>Lihat status terbaru pengaduan</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
        
        <div class="dashboard-berita">
          <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="box-berita">
              <div class="berita-image">
                <img src="image_berita/<?php echo htmlspecialchars($row['gambar']); ?>" alt="berita 1">
              </div>
            
            <a href="detail_berita.php?id=<?php echo $row['id_berita']; ?>" style="text-decoration: none;">  
              <div class="berita-judul">
                <h4>
                  <?php echo htmlspecialchars($row['judul']); ?>
                </h4>
              </div>
            </a>
            </div>
          <?php endwhile; ?>
          

        </div>

      </div>    
    </section>

    <section id="pengaduan">     
      <div class="form-container">
      <h1 style="text-align:center; color: #1d4ed8; margin-bottom: 23px;">FORM LAPORAN PENGADUAN</h1>
        <form action="proses_pengaduan.php" method="POST" enctype="multipart/form-data">
          <div class="form-group">
            <label for="nama">Nama</label>
            <span class="colon">:</span>
            <input type="text" id="nama" name="nama" required>
          </div>

          <div class="form-group">
            <label for="alamat">Alamat</label>
            <span class="colon">:</span>
            <input type="text" id="alamat" name="alamat" required>
          </div>

          <div class="form-group">
            <label for="no_hp">No HP</label>
            <span class="colon">:</span>
            <input type="tel" id="no_hp" name="no_hp" required>
          </div>

          <div class="form-group">
            <label for="umur">Umur</label>
            <span class="colon">:</span>
            <input type="number" id="umur" name="umur" required>
          </div>

          
          <div class="form-group">
            <label for="kategori">Jenis Kekerasan</label>
            <span class="colon">:</span>
            <select name="kategori" id="kategori" required>
              <option value="">-- Pilih Kategori --</option>
              <option value="kekerasan dalam rumah tangga (KDRT)">kekerasan dalam rumah tangga (KDRT)</option>
              <option value="kekerasan terhadap perempuan (KTP)">kekerasan terhadap perempuan (KTP)</option>
              <option value="kekerasan terhadap anak (KTA)">kekerasan terhadap anak (KTA)</option>
              <option value="kekerasan seksual">kekerasan seksual</option>
            </select>
          </div>

          <div class="form-group">
            <label for="laporan_text">Isi Laporan</label>
            <span class="colon">:</span>
            <textarea id="laporan_text" name="laporan" required></textarea>
          </div>

          <div class="form-group">
            <label for="bukti">Bukti Pendukung</label>
            <span class="colon">:</span>
            <input type="file" id="bukti" name="bukti" accept="image/*" required>
          </div>

          <button style="font-weight: bold;" type="submit" class="submit-btn">Kirim Laporan</button>
        </form>
      </div>
    </section>

    <section id="cek">

      <div class="form-container">
        <form onsubmit="return cariStatus(event)">
        <h1 style="text-align: center; color: #1d4ed8; margin-bottom: 15px; font-size: 26px;">CEK PENGADUAN</h1>
          <div class="form-group"> 
            <label for="cari_id">No Tiket</label>
            <input type="text" id="cari_id" required placeholder="Masukkan No Tiket">
          </div>
          <button style="font-weight: bold;" type="submit" class="submit-btn">Cek Pengaduan</button>
        </form>

        <div id="hasil-status" style="margin-top: 20px;">
          <!-- Hasil akan ditampilkan di sini -->
          <iframe id="statusFrame" style="width: 100%; height: 500px; border: none;"></iframe>

        </div>
      </div>
    
    </section>


    <?php
$koneksi = new mysqli("localhost", "root", "", "pkl");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_ulasan'])) {
    $bintang = (int) $_POST['bintang'];
    $ulasan = $koneksi->real_escape_string($_POST['ulasan']);

    if ($bintang >= 1 && $bintang <= 5 && !empty($ulasan)) {
        $query = "INSERT INTO ulasan (bintang, ulasan) VALUES ($bintang, '$ulasan')";
        if ($koneksi->query($query)) {
            echo "<script>alert('Ulasan berhasil dikirim!');</script>";
        } else {
            echo "<script>alert('Gagal menyimpan ulasan.');</script>";
        }
    }
}
?>

<section id="ulasan" class="active">
  <div class="ulasan-container">
    <h2 class="title-ulasan">Beri Rating</h2>

    <div class="star-rating">
      <span class="star" data-rating="1">&#9733;</span>
      <span class="star" data-rating="2">&#9733;</span>
      <span class="star" data-rating="3">&#9733;</span>
      <span class="star" data-rating="4">&#9733;</span>
      <span class="star" data-rating="5">&#9733;</span>
    </div>

    <form class="ulasan-form" method="POST">
      <input type="hidden" name="bintang" id="ratingValue" value="0">
      
      <label for="ulasan" class="ulasan-label">Masukkan Ulasan</label>
      <textarea name="ulasan" id="ulasan" rows="5" required class="textarea_1"></textarea>

      <button type="submit" name="submit_ulasan" class="button_1">Kirim</button>
    </form>
  </div>
</section>


    <section id="about">
      <div class="about-container">

        <div style="text-align: center;" class="about-box">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4827.206103343758!2d113.71959406875654!3d-8.170250976321027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd695cd928db2b3%3A0xf03ce39f8a35b906!2sDinas%20Pemberdayaan%20Perempuan%20Perlindungan%20Anak%20dan%20Keluarga%20Berencana%20(PPPAKB)%20Kabupaten%20Jember!5e0!3m2!1sid!2sid!4v1746706916042!5m2!1sid!2sid" 
            allowfullscreen
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>

        <div class="about-box">
          <div class="about-contact">

            <div class="logo-contact">
              <i class="fas fa-map-marker-alt"></i> 
              <span>Jl. Jawa No.51 Tegal Boto Lor Sumbersari Kec. Sumbersari Kabupaten Jember Jawa Timur 68121</span> 
            </div>

            <div class="logo-contact">
              <i class="fas fa-envelope"></i> 
              <span>dpppakb@jemberkab.go.id</span>
            </div>
            
            <div class="logo-contact">
              <i class="fas fa-phone"></i> 
              <span>(0331) 422103</spanp>
            </div>
            
          </div>
          </div>
        

        <div class="about-box">
            <h2 style="text-align: center; color: white; font-weight: bold;">
            Website Dinas Pemberdayaan Perempuan Perlindungan Anak dan Keluarga Berencana (DPPPAKB) Kabupaten Jember - Jawa Timur
            </h2>
        
            <h3 style="text-align: center; color: white; font-weight: bold; padding-top: 40px;">
              Kunjungi Kami Di :
            </h3>
        </div>

        <div class="about-box">
            <div class="about-medsos">
              <a href="https://www.tiktok.com/@dpppakbjember" target="_blank"><i class="fab fa-tiktok"></i></a>
              <a href="https://www.instagram.com/dpppakb.jember/" target="_blank"><i class="fab fa-instagram"></i></a>
              <a href="http://www.youtube.com/@dpppakbkabjember5389" target="_blank"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
      </div>
    </section>

  <script>
    function showSection(id) {
      const sections = document.querySelectorAll('section');
      sections.forEach(section => {
        section.classList.remove('active');
      });

      const target = document.getElementById(id);
      if (target) {
        target.classList.add('active');
      }
    }

    function cariStatus(event) {
      event.preventDefault(); // Mencegah form dari reload halaman
      
      const no_tiket = document.getElementById('cari_id').value.trim(); // Mendapatkan input ID Pengaduan
      const frame = document.getElementById('statusFrame'); // Mendapatkan elemen iframe

      // Cek apakah ID pengaduan valid
      if (no_tiket === "") {
        alert("Masukkan Nomer Tiket terlebih dahulu.");
        return false; // Tidak lanjutkan jika ID kosong
      }

      // Perbarui sumber iframe dengan ID yang baru
      frame.src = `status_pengaduan.php?no_tiket=${encodeURIComponent(no_tiket)}`;
      return false; // Mencegah form dari reload halaman
    }


  </script>

<script>
  const stars = document.querySelectorAll('.star');
  const ratingValue = document.getElementById('ratingValue');

  stars.forEach(star => {
    star.addEventListener('click', () => {
      const rating = star.dataset.rating;
      ratingValue.value = rating;

      // Update tampilan bintang
      stars.forEach(s => s.classList.remove('active'));
      for (let i = 0; i < rating; i++) {
        stars[i].classList.add('active');
      }
    });
  });
</script>

</body>
</html>
